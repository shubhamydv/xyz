import os,unittest,threading
import xml.etree.ElementTree as input_tree


def read(filename):
	with open(filename) as f:
		tree=input_tree.parse(filename)
		root=tree.getroot()
		arr=root.text.split()
		arr=[int(x) for x in arr]
		print arr
		return arr

def part(arr,low,high):
	p,i=arr[high],low
	for j in range(low,high):
		if(arr[j]<=p):
			arr[i],arr[j]=arr[j],arr[i]
			i+=1
	arr[high],arr[i]=arr[i],arr[high]
	return i

def quicksort(arr,low,high):
	if(low<high):
		p=part(arr,low,high)
		t1=threading.Thread(target=quicksort,args=(arr,low,p-1))
		t2=threading.Thread(target=quicksort,args=(arr,p+1,high))
		t1.start()
		t2.start()
		t1.join()
		print t1.getName()
		t2.join()
		print t2.getName()

class Test(unittest.TestCase):
	def test_postive(self):
		self.assertEquals(read("input.xml"),[5, 4, 3, 2, 1])
	def test_negative(self):
		self.assertRaises(IOError,read,"input.txt")

lst=read('input.xml')
print lst
quicksort(lst,0,len(lst)-1)
print "Sorted Array:"+ str(lst)

print "\nTesting Results...."
unittest.main()
